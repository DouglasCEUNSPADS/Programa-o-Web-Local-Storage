if (localStorage.estado)
{
   document.getElementById('estado').value = localStorage.estado;
}
if (localStorage.modelo)
{
   document.getElementById('modelo').value = localStorage.modelo;
}
if (localStorage.cor)
{
   document.getElementById('cor').value = localStorage.cor;
}
if (localStorage.dataInicio)
{
   document.getElementById('dataInicio').value = localStorage.dataInicio;
}
if (localStorage.dataFinal)
{
   document.getElementById('dataFinal').value = localStorage.dataFinal;
}

var salvarData = function()
{
   var estado = document.getElementById('estado').value;
   var modelo = document.getElementById('modelo').value;
   var cor = document.getElementById('cor').value;
   var dataInicio = document.getElementById('dataInicio').value;
   var dataFinal = document.getElementById('dataFinal').value;

   localStorage.setItem('estado', estado);
   localStorage.setItem('modelo', modelo);
   localStorage.setItem('cor', cor);
   localStorage.setItem('dataInicio', dataInicio);
   localStorage.setItem('dataFinal', dataFinal);
};

document.onchange = salvarData;